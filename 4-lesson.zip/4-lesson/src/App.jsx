import { useState } from "react";
import hamster from "./assets/hamster.png"

function App() {
  const [number, setNumber] = useState(0);
  const [add, setAdd] = useState(1);
  
  const addFunction = () => {
    setNumber((prevNumber) => {
      const newNumber = prevNumber + add;
  
      if (newNumber >= 100) {
        setAdd(Math.floor(newNumber / 100) + 1);
      }
  
      return newNumber;
    });
  };
  

  return (
    <>
      <div className=" flex flex-col items-center justify-center h-[100vh] gap-10 bg-gray-600">
        <h3 className=" flex text-[30px] font-semibold text-yellow-400 items-center gap-5 ">
          {number}
          <img className=" w-11" src="https://img.cryptorank.io/coins/hamster_kombat1727340368581.png" alt="" />
        </h3>
        <button
          className="rounded-full bg-blue-500 border-blue-700 border-[20px] border text-white cursor-pointer text-[60px]"
          onClick={addFunction}
        >
          <img className=" w-[400px] mb-4" src={hamster} alt="+" />
        </button>
      </div>
    </>
  );
}

export default App;
